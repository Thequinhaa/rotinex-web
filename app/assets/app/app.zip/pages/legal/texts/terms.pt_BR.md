# Termos de Uso do Rotinex

**Versão 2026-11 · Rascunho sujeito a revisão jurídica.** Este texto ainda será revisado por um advogado antes do lançamento.

Estes termos são o acordo entre você e **Maria Thereza Alexandre Monteiro**, pessoa física, de Nazaré da Mata (PE), responsável pelo Rotinex para o uso do Rotinex (site, app no navegador e apps de celular). Ao criar a conta, você declara que leu e aceita estes termos e a Política de Privacidade.

## 1. O que é o Rotinex

O Rotinex é uma ferramenta de organização pessoal: você registra suas rotinas, finanças, treinos, alimentação, saúde e outras áreas, acompanha painéis, ganha pontos e recebe sugestões de recompensa.

**O Rotinex não é consultoria médica, nutricional, psicológica, financeira, jurídica nem de educação física.** As informações, gráficos e sugestões do app servem para você se organizar e não substituem profissionais. Em caso de dúvida sobre saúde, alimentação, treino ou dinheiro, procure um profissional habilitado.

## 2. Sua conta

- É preciso ter **12 anos ou mais**. De 12 a 17 anos, só com a autorização e o acompanhamento de mãe, pai ou responsável legal, que também aceita estes termos e responde pela contratação e pelo pagamento da assinatura.
- Use um e-mail válido e uma senha só sua. Você é responsável pelo que acontece na sua conta; se suspeitar de uso indevido, troque a senha e nos avise.
- Uma conta é pessoal e não deve ser compartilhada.

## 3. Teste grátis e planos

- Toda conta nova tem **12 dias grátis do plano Completo**, sem cartão de crédito.
- Depois do teste, você pode assinar:
  - **Basic:** R$ 15 por mês (cobrado mês a mês, 12 vezes no ano) ou R$ 100 por ano. Inclui Rotina, Finanças, Treino, Alimentação, Saúde, Casa, pontos e recompensas, páginas em PDF para imprimir, importação de extrato bancário e integração com a agenda.
  - **Completo:** R$ 25 por mês (12 vezes no ano) ou R$ 200 por ano. Inclui tudo do Basic, todas as áreas da vida, a página IA e os demais recursos do plano.
- Os preços podem mudar; se mudarem, avisaremos antes e o novo valor só vale a partir da renovação seguinte.
- Se o teste acabar ou a assinatura terminar sem renovação, **seus dados continuam guardados**, mas ficam somente para leitura até você assinar.

## 4. Pagamento, cancelamento e reembolso

- A cobrança é feita por um provedor de pagamento. O Rotinex não guarda o número do seu cartão.
- Você pode cancelar quando quiser. O acesso continua até o fim do período já pago.
- **Direito de arrependimento:** em compras pela internet, você pode desistir em até **7 dias** da contratação e receber o valor de volta, como garante o Código de Defesa do Consumidor (art. 49).
- Nesta fase de testes o Rotinex não faz cobranças. As regras de reembolso fora do prazo de 7 dias (principalmente no plano anual) serão publicadas aqui antes de qualquer cobrança.

## 5. Página IA (lançar com inteligência artificial)

- A IA organiza o que você escreve ou fala e **sempre mostra uma lista para você conferir antes de salvar**. Ela pode errar: confira os itens antes de confirmar.
- O uso tem um **limite diário** por pessoa, para manter o serviço disponível para todos.
- Para funcionar, o texto ou o áudio é enviado ao serviço de IA da Cloudflare apenas para ser organizado (veja a Política de Privacidade).

## 6. Regras de uso

Você concorda em não:

- tentar acessar dados de outras pessoas ou partes do sistema que não são suas;
- atacar, sobrecarregar ou tentar burlar a proteção do serviço (inclusive com robôs);
- usar o Rotinex para algo ilegal ou para guardar conteúdo de terceiros sem autorização;
- copiar, revender ou criar produtos a partir do Rotinex sem autorização.

Podemos suspender ou encerrar contas que descumpram estas regras, avisando você quando possível.

## 7. Seus dados e seu conteúdo

- **O que você registra é seu.** Você pode baixar uma cópia (Configurações → Exportar meus dados) ou excluir a conta e os dados (Configurações → Excluir minha conta) quando quiser.
- Você nos autoriza a guardar e processar esse conteúdo apenas para prestar o serviço, como descrito na Política de Privacidade.

## 8. Disponibilidade

Trabalhamos para o Rotinex funcionar bem e sem interrupções, mas ele pode ficar indisponível em alguns momentos (manutenção, falhas de fornecedores, problemas de internet). O app guarda uma cópia dos dados no seu aparelho para continuar funcionando sem internet. Mantenha cópias próprias do que for muito importante (você pode exportar seus dados a qualquer momento).

## 9. Responsabilidade

Respondemos pelos nossos serviços nos termos do Código de Defesa do Consumidor. Não somos responsáveis por decisões que você tomar com base nos registros e sugestões do app, nem por falhas do seu aparelho ou da sua internet.

## 10. Propriedade intelectual

A marca Rotinex, o logo, o design, os textos e as ilustrações do app pertencem ao Rotinex. Você recebe uma permissão pessoal e não exclusiva para usar o app enquanto sua conta estiver ativa.

## 11. Mudanças nestes termos

Se estes termos mudarem de forma importante, avisaremos no app com antecedência. Continuar usando depois da mudança significa aceitar a nova versão; se não concordar, você pode cancelar e excluir a conta.

## 12. Lei e foro

Estes termos seguem as leis do Brasil. Fica eleito o foro do domicílio do consumidor.

## 13. Contato

Dúvidas sobre estes termos: **rotinexapp@gmail.com**.
