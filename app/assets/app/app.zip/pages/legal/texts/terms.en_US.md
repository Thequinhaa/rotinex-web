# Rotinex Terms of Use

**Version 2026-11 · Draft subject to legal review.** This text will be reviewed by a lawyer before launch.

These terms are the agreement between you and **Maria Thereza Alexandre Monteiro**, an individual from Nazaré da Mata (PE), Brazil, responsible for Rotinex for using Rotinex (website, browser app and phone apps). By creating an account, you state that you have read and accept these terms and the Privacy Policy.

## 1. What Rotinex is

Rotinex is a personal organization tool: you record your routines, finances, workouts, meals, health and other areas, follow panels, earn points and get reward suggestions.

**Rotinex is not medical, nutritional, psychological, financial, legal or fitness advice.** The app's information, charts and suggestions are meant to help you get organized and do not replace professionals. If you have questions about health, food, training or money, look for a qualified professional.

## 2. Your account

- You must be **12 years or older**. From 12 to 17, only with the authorization and supervision of a parent or legal guardian, who also accepts these terms and is responsible for the subscription and its payment.
- Use a valid e-mail and a password that is only yours. You are responsible for what happens in your account; if you suspect misuse, change your password and let us know.
- An account is personal and must not be shared.

## 3. Free trial and plans

- Every new account gets **12 free days of the Complete plan**, with no credit card.
- After the trial, you can subscribe:
  - **Basic:** R$ 15 per month (charged monthly, 12 times a year) or R$ 100 per year. Includes Routine, Finance, Workout, Nutrition, Health, Home, points and rewards, printable PDF pages, bank statement import and calendar integration.
  - **Complete:** R$ 25 per month (12 times a year) or R$ 200 per year. Includes everything in Basic, every life area, the AI page and the plan's other features.
- Prices may change; if they do, we will tell you in advance and the new price only applies from the next renewal.
- If the trial ends or the subscription ends without renewal, **your data stays saved**, but it becomes read-only until you subscribe.

## 4. Payment, cancellation and refunds

- Billing is done by a payment provider. Rotinex does not store your card number.
- You can cancel at any time. Access continues until the end of the period already paid.
- **Right of withdrawal:** for online purchases, you can withdraw within **7 days** of subscribing and get your money back, as guaranteed by Brazil's Consumer Protection Code (art. 49).
- During this test phase Rotinex charges nothing. Refund rules after the 7-day period (especially for the yearly plan) will be published here before any charge.

## 5. AI page (add with artificial intelligence)

- The AI organizes what you write or say and **always shows a list for you to check before saving**. It can make mistakes: check the items before confirming.
- Use has a **daily limit** per person, to keep the service available for everyone.
- To work, the text or audio is sent to Cloudflare's AI service only to be organized (see the Privacy Policy).

## 6. Rules of use

You agree not to:

- try to access other people's data or parts of the system that are not yours;
- attack, overload or try to get around the service's protection (including with bots);
- use Rotinex for anything illegal or to store third-party content without permission;
- copy, resell or build products from Rotinex without permission.

We may suspend or close accounts that break these rules, telling you when possible.

## 7. Your data and your content

- **What you record is yours.** You can download a copy (Settings → Export my data) or delete your account and data (Settings → Delete my account) whenever you want.
- You allow us to store and process this content only to provide the service, as described in the Privacy Policy.

## 8. Availability

We work to keep Rotinex running well and without interruptions, but it may be unavailable at times (maintenance, provider failures, internet problems). The app keeps a copy of your data on your device to keep working offline. Keep your own copies of anything very important (you can export your data at any time).

## 9. Liability

We are liable for our services under Brazil's Consumer Protection Code. We are not responsible for decisions you make based on the app's records and suggestions, nor for failures of your device or internet connection.

## 10. Intellectual property

The Rotinex brand, logo, design, texts and illustrations belong to Rotinex. You receive a personal, non-exclusive permission to use the app while your account is active.

## 11. Changes to these terms

If these terms change in an important way, we will tell you in the app in advance. Continuing to use the app after the change means accepting the new version; if you do not agree, you can cancel and delete your account.

## 12. Law and jurisdiction

These terms follow the laws of Brazil. The courts of the consumer's place of residence are chosen to settle disputes.

## 13. Contact

Questions about these terms: **rotinexapp@gmail.com**.
