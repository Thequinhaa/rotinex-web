# Rotinex Privacy Policy

**Version 2026-11 · Draft subject to legal review.** This text will be reviewed by a lawyer specialized in data protection before launch.

Rotinex is an app to organize the areas of your life (finance, routine, workout, nutrition, health, home, studies, career, beauty, travel and pets). To work, it keeps information that you record yourself. This policy explains, in plain words, which data we process, why, with whom and how you control it, under Brazil's General Data Protection Law (LGPD, Law 13,709/2018).

## 1. Who takes care of your data

The data controller is **Maria Thereza Alexandre Monteiro**, an individual from Nazaré da Mata (PE), Brazil.

For any privacy matter, including exercising your rights, write to **rotinexapp@gmail.com**. We answer within 15 days.

## 2. What data we process

- **Account:** e-mail, password (kept only in encrypted form by the sign-in service, never by us), what you like to be called, language, currency, theme and the order of the areas in the menu. If you sign in with Google, we receive your Google account's name and e-mail.
- **What you record in each area:** finance entries and bills, habits, tasks and goals, workouts and body measurements, meals and shopping list, health information, home chores, studies, career, beauty care, trips, your pets' information, challenges and sleep mode, rewards and the suggestions you send.
- **Health data (sensitive data):** sleep, medicines, appointments, tests, mood, menstrual cycle (off by default), measurements and weight, heart rate and calories from imported workouts. We only process this data with your **specific consent**, asked separately at sign-up.
- **Attachments:** files you choose to attach (receipts, test results, documents). With your account, our API **encrypts** them and keeps them in a private folder of your own on Supabase (São Paulo region). Without an account, they stay only on your device.
- **Product feedback:** the ideas and problems you send and your votes on the team's ideas. The Rotinex team reads them without your name or e-mail; that's why we ask you not to write personal data in them.
- **Add with AI:** the text you write or the audio you record on the AI page, only at the moment it is organized. We only keep how many times you used the AI each day.
- **Subscription:** plan, status and dates. Payments will be handled by a payment provider; **your card number never goes through Rotinex**.
- **Technical data:** IP address, browser type and access and error logs, used for security and to keep the service running.

We do not ask for ID numbers, address, identity documents or bank details to use the app.

## 3. Why we use it

- To create and keep your account and show your data on all your devices.
- To compute the app's panels (consistency, points, charts, reward suggestions).
- To organize automatically what you write or say on the AI page, always with your confirmation before saving.
- To manage the free trial and the subscription.
- To protect the service against abuse, bots and unauthorized access.
- To answer your requests and questions.

**We do not sell your data, do not use it for advertising and do not send marketing e-mails.**

## 4. Legal bases

- **Performance of a contract** (art. 7, V): account, area data, syncing, subscription.
- **Specific and prominent consent** (art. 11, I): health data. You can withdraw this consent at any time.
- **Legitimate interest and legal obligation** (art. 7, IX and II; Brazilian Internet Civil Framework): security and access logs.

## 5. Who we share it with

We use companies that provide services so Rotinex can work (processors). They may only use the data to serve us:

- **Supabase:** database, sign-in and attachment storage. Data is kept on servers in the **São Paulo (Brazil)** region.
- **Render:** server running our API (may be outside Brazil).
- **Cloudflare:** bot protection at sign-up and sign-in (Turnstile) and the artificial intelligence of the AI page (Workers AI), which receives the text or audio only to organize it.
- **Google:** only if you choose to sign in with Google.
- **GitHub Pages:** hosting of the website pages (no personal data).
- **Payment provider (Stripe):** once billing is active, to process the subscription.

We may also share data when a law or court order requires it.

## 6. International transfer

Some of these providers may process data outside Brazil. In those cases the transfer follows art. 33 of the LGPD, with providers that offer protection guarantees compatible with Brazilian law.

## 7. How long we keep it

- While your account exists.
- When you **delete your account** (Settings → Delete my account), we immediately erase your data from our database and your sign-in.
- Text and audio sent to the AI are not kept by us after being organized.
- Technical access logs may be kept for up to 6 months, as required by the Brazilian Internet Civil Framework.

## 8. How we protect it

- Area data is **encrypted** (AES-256) before it reaches the database.
- All communication uses a secure connection (HTTPS).
- The app never reaches the database directly: everything goes through our API, which checks who you are on every request.
- The database blocks any access through the public keys.
- Bot protection at sign-up and sign-in.

No system is 100% secure. If an incident that may bring risk to you happens, we will tell you and Brazil's Data Protection Authority (ANPD).

## 9. Your rights

Under the LGPD (art. 18), you can:

- confirm whether we process your data and access it;
- **download a copy** of everything (Settings → Export my data);
- correct data (directly in each area of the app);
- **delete your account and data** (Settings → Delete my account);
- withdraw consent for health data (through the privacy e-mail, until this option reaches Settings);
- know who we share your data with (section 5);
- ask for information or complain, including to the ANPD.

## 10. Storage on your device

The app keeps a copy of your data on your device or browser, to open fast and work offline. When you sign out, this copy is erased. The website uses no advertising cookies or trackers. Bot protection (Cloudflare Turnstile) may use its own technical cookies.

## 11. Minimum age

Rotinex is intended for people **12 years or older**. For people aged 12 to 17, use depends on the authorization and supervision of a parent or legal guardian, and we always process the data in the teenager's best interest (LGPD, art. 14). We do not accept accounts of children under 12; if we learn of one, it will be deleted.

## 12. Changes to this policy

If this policy changes in an important way, we will tell you in the app and ask for a new acceptance when the law requires it. The version and date are at the top of this text.
